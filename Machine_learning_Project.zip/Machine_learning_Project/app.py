import streamlit as st
import time
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(layout="wide")

from notebooks.main_code_file import (
    load_data,
    finding_num_cat_columns,
    preprocessing,
    Remove_Outliers,
    Detect_Outliers,
    check_parameters,
    graph_plot,
    show_intro_animation,
)

# Initialize session state variables
if "data" not in st.session_state:
    st.session_state["data"] = None
if "preprocessed_data" not in st.session_state:
    st.session_state["preprocessed_data"] = None
if "target_column" not in st.session_state:
    st.session_state["target_column"] = None
if "outliers_detected" not in st.session_state:
    st.session_state["outliers_detected"] = False
if "correlation_plotted" not in st.session_state:
    st.session_state["correlation_plotted"] = False
if "graphs_plotted" not in st.session_state:
    st.session_state["graphs_plotted"] = False

# Sidebar for user input
st.sidebar.markdown(
    """
                    <style>
                        .sidebar-title{
                            margin-bottom:20px;
                            font-size:40px;
                            text-align:center;
                            font-weight:bolder;
                            letter-spacing:0.5px;
                        }
                    </style>
                    <div class="sidebar-title">Settings</div>
                    """,
    unsafe_allow_html=True,
)
uploaded_file = st.sidebar.file_uploader("Upload Dataset (CSV)", type=["csv"])
success_placeholder = st.empty()

# File upload handling
if uploaded_file:
    if (
        "previous_file_name" not in st.session_state
        or st.session_state["previous_file_name"] != uploaded_file.name
    ):
        st.session_state["previous_file_name"] = uploaded_file.name
        st.session_state["data"] = None
        st.session_state["preprocessed_data"] = None
        st.session_state["target_column"] = None
        st.session_state["outliers_detected"] = False
        st.session_state["correlation_plotted"] = False
        st.session_state["graphs_plotted"] = False

if not uploaded_file:
    show_intro_animation()
else:
    try:
        # Display welcome animation
        st.markdown(
            """
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@400;900&display=swap');
                .centered-container {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;                
                }
                .title {
                    font-family: "Kanit", sans-serif;
                    font-weight: 900;
                    font-size: 65px;
                    color: #4A90E2;
                    text-align: center;
                    margin-bottom: 20px;
                    animation: slideUp 1s ease-out;
                }
                .stDataFrame {
                    border: 2px solid #f0f0f0;  /* Add white border */
                }
                .button-container {
                    display: flex;
                    justify-content: center;
                    margin: 20px 0;
                }
                .button-container > button {
                    margin: 0 10px;
                }
            </style>
            <div class="centered-container">
                <div class="title">Welcome to Optimal Predictor</div>            
            </div>
            """,
            unsafe_allow_html=True,
        )
        # Load dataset
        if st.session_state["data"] is None:
            st.session_state["data"] = load_data(uploaded_file)

        success_placeholder.success(
            f"✅ Dataset '{uploaded_file.name}' uploaded successfully!"
        )
        time.sleep(1.5)
        success_placeholder.empty()

        data = st.session_state["data"]
        st.markdown("<h2>1) Uploaded Dataset</h2>", unsafe_allow_html=True)
        st.dataframe(data.head(15), width=1800)

        # Outlier Detection
        if not st.session_state["outliers_detected"]:
            st.markdown("<h2>2) Outlier Detection</h2>", unsafe_allow_html=True)
            outliers = Detect_Outliers(data, threshold=3)
            total_outliers = sum(len(outliers[col][1]) for col in outliers.keys())

            if total_outliers > 0:
                st.markdown(f"<span style='color: orange; font-weight: bold;margin-left:30px;margin-top:30px;'>Total Detected Outliers: {total_outliers}</span>",unsafe_allow_html=True)
                threshold = st.sidebar.slider("Outlier Detection Threshold", 1, 3, 3)
                remove_outliers = st.sidebar.checkbox("Remove Outliers", value=True)
                strategy = st.sidebar.radio(
                    "Outlier Handling", ["Trimming", "Capping"], index=1
                )

                if remove_outliers:
                    filtered_data = Remove_Outliers(data, outliers, threshold, strategy)
                else:
                    filtered_data = data
            else:
                st.markdown("No outliers detected.")
                filtered_data = data

            st.session_state["outliers_detected"] = True
        else:
            filtered_data = data

        # Preprocessing
        st.markdown("<h2>3) Preprocessed Data</h2>", unsafe_allow_html=True)
        columns = finding_num_cat_columns(filtered_data)
        preprocessed_data, target = preprocessing(filtered_data, columns)

        st.session_state["preprocessed_data"] = preprocessed_data
        st.session_state["target_column"] = target

        st.dataframe(preprocessed_data.head(15), width=1800)

        # Correlation Heatmap
        if not st.session_state["correlation_plotted"]:
            st.markdown("<h2>4) Correlation Matrix</h2>", unsafe_allow_html=True)
            corr = preprocessed_data.corr()
            plt.figure(figsize=(20, 12))
            sns.heatmap(
                corr,
                annot=True,
                fmt=".2f",
                cmap="coolwarm",
                cbar=False,
                annot_kws={"size": 12},
                linewidths=0.5,
            )
            plt.title("Correlation Matrix")
            st.pyplot(plt)
            st.session_state["correlation_plotted"] = True

        # Data Visualization Graphs
        if not st.session_state["graphs_plotted"]:
            st.markdown("<h2>5) Data Visualization</h2>", unsafe_allow_html=True)
            graph_plot(preprocessed_data)
            st.session_state["graphs_plotted"] = True

        # Model Training Section
        st.markdown("<h2>6) Model Training</h2>", unsafe_allow_html=True)

        model_name = st.sidebar.selectbox(
            "Select a Model to Train",
            ["Decision Tree", "Random Forest", "Linear Regression", "SVR", "AdaBoost"],
        )

        if model_name == "Linear Regression":
            independent_column = st.sidebar.selectbox(
                "Select Independent Variable (X)", options=preprocessed_data.columns
            )
            dependent_column = st.sidebar.selectbox(
                "Select Dependent Variable (y)",
                options=preprocessed_data.columns,
                index=1,
            )

            st.button("Initiate Training")
            if not independent_column or not dependent_column:
                st.error(
                    "Please select both an independent and dependent variable for Linear Regression."
                )
            else:
                spinner_placeholder = st.empty()
                message_placeholder = st.empty()

                spinner_texts = [
                    "Initializing training...",
                    f"Training the model: {model_name}...",
                    "Evaluating model performance...",
                    "Finalizing results...",
                ]

                for spinner_text in spinner_texts:
                    spinner_placeholder.text(spinner_text)
                    time.sleep(3.5)

                try:
                    model_results = check_parameters(
                        preprocessed_data[[independent_column, dependent_column]],
                        model_name,
                        dependent_column,
                    )
                    if model_results:
                        message_placeholder.success(
                            f"Training for {model_name} completed successfully!"
                        )
                        time.sleep(2.5)
                        message_placeholder.empty()
                        st.write(
                            f"**Best Parameters for {model_name}:**",
                            model_results["best_params"],
                        )
                        st.write(
                            f"**Best Score for {model_name}:**",
                            model_results["best_score"],
                        )
                    else:
                        message_placeholder.warning(
                            "Training completed, but no results found."
                        )
                except Exception as e:
                    message_placeholder.error(f"Training failed: {e}")

                spinner_placeholder.empty()
        else:
            target_column = st.sidebar.selectbox(
                "Select Target Column",
                options=["Auto-detect"] + list(preprocessed_data.columns),
            )

            if st.button("Initiate Model"):
                if target_column == "Auto-detect":
                    target_column = st.session_state["target_column"]

                if not target_column:
                    st.error(
                        "No target column detected. Please select a target column."
                    )
                else:
                    spinner_placeholder = st.empty()
                    message_placeholder = st.empty()

                    spinner_texts = [
                        "Initializing training...",
                        f"Training the model: {model_name}...",
                        "Evaluating model performance...",
                        "Finalizing results...",
                    ]

                    for spinner_text in spinner_texts:
                        spinner_placeholder.text(spinner_text)
                        time.sleep(1.5)

                    try:
                        model_results = check_parameters(
                            st.session_state["preprocessed_data"],
                            model_name,
                            target=target_column,
                        )
                        if model_results:
                            message_placeholder.success(
                                f"Training for {model_name} completed successfully!"
                            )
                            st.write(
                                f"**Best Parameters for {model_name}:**",
                                model_results["best_params"],
                            )
                            st.write(
                                f"**Best Score for {model_name}:**",
                                model_results["best_score"],
                            )
                        else:
                            message_placeholder.warning(
                                "Training completed, but no results found."
                            )
                    except Exception as e:
                        message_placeholder.error(f"Training failed: {e}")

                    spinner_placeholder.empty()

        st.markdown("</div>", unsafe_allow_html=True)
    except Exception as e:
        st.error(f"Error: {e}")
        st.info("Please upload a valid CSV file to proceed.")
