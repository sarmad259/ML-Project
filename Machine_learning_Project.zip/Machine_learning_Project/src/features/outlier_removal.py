# Outliers Removal

def Remove_Outliers(data, outliers_info, threshold=3, strategy='capping'):
    for column, (method, outliers) in outliers_info.items():
        if strategy.lower() == 'capping':
            if method.lower() == 'zscore':
                # Method for removing outliers with z-score and capping
                upper_bound = data[column].mean() + threshold * data[column].std()
                lower_bound = data[column].mean() - threshold * data[column].std()
                data[column] = np.where(data[column] > upper_bound, upper_bound,
                                        np.where(data[column] < lower_bound, lower_bound, data[column]))

            elif method.lower() == 'iqr':
                # Method for capping based on IQR
                Q1 = data[column].quantile(0.25)
                Q3 = data[column].quantile(0.75)
                IQR = Q3 - Q1
                upper_bound = Q3 + 1.5 * IQR
                lower_bound = Q1 - 1.5 * IQR
                data[column] = np.where(data[column] > upper_bound, upper_bound,
                                        np.where(data[column] < lower_bound, lower_bound, data[column]))

        elif strategy.lower() == 'trimming':
            if method.lower() == 'zscore':
                # Method for trimming using Z-score
                upper_bound = data[column].mean() + threshold * data[column].std()
                lower_bound = data[column].mean() - threshold * data[column].std()
                data[column] = data[column].where((data[column] >= lower_bound) & (data[column] <= upper_bound))

            elif method.lower() == 'iqr':
                # Method for trimming using IQR
                Q1 = data[column].quantile(0.25)
                Q3 = data[column].quantile(0.75)
                IQR = Q3 - Q1
                upper_bound = Q3 + 1.5 * IQR
                lower_bound = Q1 - 1.5 * IQR
                data[column] = data[column].where((data[column] >= lower_bound) & (data[column] <= upper_bound))

            # Drop NaNs only if there are no valid entries
            data[column] = data[column].fillna(data[column].median())  # Filling NaNs with median or use another strategy if needed

    return data