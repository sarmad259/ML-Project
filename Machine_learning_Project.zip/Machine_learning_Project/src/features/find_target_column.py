def find_target_column(data):
    numeric_cols = data.select_dtypes(include=['int64', 'float64', 'number'])
    correlations = numeric_cols.corr()
    avg_corr = correlations.mean().sort_values(ascending=False)
    threshold = max(avg_corr)
    target_col = next((col for col, corr in avg_corr.items() if corr >= threshold), None)
    return target_col