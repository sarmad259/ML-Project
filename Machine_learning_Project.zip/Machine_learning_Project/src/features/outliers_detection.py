"""# **Outliers Detection**"""

def Detect_Outliers(data, threshold):
    outliers_info = {}  # Store information about outliers

    for column in data.select_dtypes(include=['number']).columns:

        skewness = data[column].skew()

        if abs(skewness) < 0.5:
            column_outliers = outliersFinding_ZScore(data[[column]], threshold)
            outliers_info[column] = ('zscore', column_outliers)
        else:
            column_outliers = outliersFinding_IQR(data[[column]])
            outliers_info[column] = ('iqr', column_outliers)

    return outliers_info