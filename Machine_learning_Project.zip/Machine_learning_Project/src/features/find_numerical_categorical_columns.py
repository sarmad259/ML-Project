# Columns Finding

def finding_num_cat_columns(data):
    data.drop_duplicates(inplace=True)

    numerical_columns = []
    categorical_columns = []

    for i in data.dtypes.index:
        if data.dtypes[i] == 'int64' or data.dtypes[i] == 'float64':
            numerical_columns.append(i)
        elif data.dtypes[i] == 'object':
            categorical_columns.append(i)

    columns = {
        'numerical_columns': numerical_columns,
        'categorical_columns': categorical_columns,
    }
    return columns