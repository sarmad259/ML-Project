# Outlier Finding Methods

def outliersFinding_ZScore(data, threshold=3):
    outliers = pd.DataFrame()

    for i in data.columns:
        mean = np.mean(data[i])
        std = np.std(data[i])
        z_scores = (data[i] - mean) / std
        column_outliers = data[(z_scores > threshold) | (z_scores < -threshold)]
        column_outliers.drop_duplicates(inplace=True)

        outliers = pd.concat([outliers, column_outliers])

    outliers = outliers.drop_duplicates()
    return outliers

# Finding outliers using IQR method
def outliersFinding_IQR(data):
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1

    outliers = (data < (Q1 - 1.5 * IQR)) | (data > (Q3 + 1.5 * IQR))
    return data[outliers.any(axis=1)]