# Check Parameters

def check_parameters(data, model_name, target=None):
    if target not in data.columns:
        raise ValueError(f"Target column '{target}' not found in the dataset.")

    X = data.drop(columns=[target])
    y = data[target]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model_results = model_cross_validation(X_train, y_train, model_name)

    return {
        "best_params": model_results.best_params_,
        "best_score": model_results.best_score_,
    }