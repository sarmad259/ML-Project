# Model Cross-Validation

def model_cross_validation(X_train, y_train, model_name):
    model_params = {
        "Decision Tree": {
            "model": DecisionTreeRegressor(),
            "param_grid": {
                "max_depth": [None, 5, 10, 15],
                "min_samples_split": [2, 5, 10],
                "min_samples_leaf": [1, 2, 4],
            },
        },
        "Random Forest": {
            "model": RandomForestRegressor(),
            "param_grid": {
                "n_estimators": [50, 100, 150],
                "max_depth": [None, 5, 10, 15],
                "min_samples_split": [2, 5, 10],
                "min_samples_leaf": [1, 2, 4],
            },
        },
        "Linear Regression": {
            "model": LinearRegression(),
            "param_grid": {
                "fit_intercept": [True, False],
            },
        },
        "SVR": {
            "model": SVR(),
            "param_grid": {
                "C": [0.1, 1, 10],
                "kernel": ["linear", "rbf"],
                "epsilon": [0.1, 0.2, 0.5],
            },
        },
        "AdaBoost": {
            "model": AdaBoostRegressor(),
            "param_grid": {
                "n_estimators": [50, 100, 150],
                "learning_rate": [0.01, 0.1, 1],
            },
        },
    }

    if model_name not in model_params:
        raise ValueError(f"Model '{model_name}' is not supported. Available models: {list(model_params.keys())}")

    config = model_params[model_name]
    random_search = RandomizedSearchCV(
        estimator=config["model"],          
        param_distributions=config["param_grid"],
        cv=10,                               
        n_iter=10,
        scoring=["neg_mean_squared_error","r2"],
        refit="r2",
        n_jobs=-1,                          
        random_state=42,                    
        verbose=1,                    
    )

    random_search.fit(X_train, y_train)
    return random_search