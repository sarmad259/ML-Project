def preprocessing(data, columns, target=None):
    categorical_columns = [col for col in columns['categorical_columns'] if col != target]

    # Numerical pipeline
    num_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    # Categorical pipeline
    cat_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('encoder', OrdinalEncoder())
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', num_pipeline, columns['numerical_columns']),
            ('cat', cat_pipeline, categorical_columns)
        ],
        remainder='drop'
    )

    processed_data = preprocessor.fit_transform(data)
    column_names = columns['numerical_columns'] + categorical_columns
    
    if len(column_names) != processed_data.shape[1]:
        column_names = column_names[:processed_data.shape[1]]
        
    processed_df = pd.DataFrame(processed_data, columns=column_names, index=data.index)

    if target is not None and target in data.columns:
        processed_df[target] = data[target]
    else:
        target = find_target_column(processed_df)
    return processed_df, target
