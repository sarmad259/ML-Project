# Graph Plotting

def graph_plot(data):
    for col in data.columns:
        plt.figure(figsize=(20, 5))

        plt.subplot(1, 2, 1)
        sns.boxplot(data[col])
        plt.title(f'Boxplot: {col}')
        plt.xticks(rotation=90)

        plt.subplot(1, 2, 2)
        sns.histplot(data[col], kde=True)
        plt.title(f'Histogram: {col}')
        plt.xticks(rotation=90)

        st.pyplot(plt)