import pandas as pd

def load_data(file):
    data = pd.read_csv(file)
    data = data[:5000]
    return data